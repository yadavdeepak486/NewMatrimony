import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stepper-demo',
  templateUrl: './stepper-demo.component.html',
  styleUrls: ['./stepper-demo.component.scss']
})
export class StepperDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
