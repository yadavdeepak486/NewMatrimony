import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-package',
  templateUrl: './add-new-package.component.html',
  styleUrls: ['./add-new-package.component.scss']
})
export class AddNewPackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  breadcrumb = [
    {
        title: 'Add New Package',
        subTitle: 'Premium member'
    }
]
}
