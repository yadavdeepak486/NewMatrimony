import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-role',
  templateUrl: './add-new-role.component.html',
  styleUrls: ['./add-new-role.component.scss']
})
export class AddNewRoleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
